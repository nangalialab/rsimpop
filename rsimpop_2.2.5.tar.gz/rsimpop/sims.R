
##  Some 
age_6wks=6/52
age_40wks=40/52
age.sample=10
run_sim=function(age1,age2,s){
  run_selection_sim(0.1,1/(2*190),target_pop_size = 1e5,nyears =age2,fitness=s,nyears_driver_acquisition = age1,minprop = 2e-5)
}